package dev.chunkflow.optimizer;

import net.minecraftforge.fml.common.Mod;

@Mod(ChunkFlow.MOD_ID)
public final class ChunkFlow {
    public static final String MOD_ID = "chunkflow";

    public ChunkFlow() {
        // v0.1 intentionally starts as a measurement-only build.
    }
}
