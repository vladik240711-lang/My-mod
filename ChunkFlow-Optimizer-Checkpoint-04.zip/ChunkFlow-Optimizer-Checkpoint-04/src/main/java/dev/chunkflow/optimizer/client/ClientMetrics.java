package dev.chunkflow.optimizer.client;

import dev.chunkflow.optimizer.ChunkFlow;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

@Mod.EventBusSubscriber(modid = ChunkFlow.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientMetrics {
    private static final long SAMPLE_INTERVAL_NS = 5_000_000_000L;
    private static long lastSampleNs = 0L;
    private static long renderFrames = 0L;
    private static Path csvPath;
    private static boolean headerWritten = false;

    private ClientMetrics() { }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            renderFrames++;
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.level == null || mc.player == null) {
            lastSampleNs = 0L;
            renderFrames = 0L;
            return;
        }

        long now = System.nanoTime();
        if (lastSampleNs == 0L) {
            lastSampleNs = now;
            renderFrames = 0L;
            return;
        }

        long elapsedNs = now - lastSampleNs;
        if (elapsedNs < SAMPLE_INTERVAL_NS) return;
        int fps = (int) Math.round(renderFrames * 1_000_000_000.0D / elapsedNs);
        lastSampleNs = now;
        renderFrames = 0L;

        Runtime runtime = Runtime.getRuntime();
        long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L);
        long allocatedMb = runtime.totalMemory() / (1024L * 1024L);
        long maxMb = runtime.maxMemory() / (1024L * 1024L);
        int chunkX = MathHelper.floor(mc.player.getX()) >> 4;
        int chunkZ = MathHelper.floor(mc.player.getZ()) >> 4;
        appendSample(System.currentTimeMillis(), fps, usedMb, allocatedMb, maxMb, chunkX, chunkZ);
    }

    private static void appendSample(long timestamp, int fps, long usedMb, long allocatedMb,
                                     long maxMb, int chunkX, int chunkZ) {
        try {
            if (csvPath == null) {
                Path directory = Minecraft.getInstance().gameDirectory.toPath().resolve("chunkflow");
                Files.createDirectories(directory);
                csvPath = directory.resolve("metrics.csv");
            }
            boolean newFile = !Files.exists(csvPath) || Files.size(csvPath) == 0L;
            try (BufferedWriter writer = Files.newBufferedWriter(csvPath, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                if (newFile && !headerWritten) {
                    writer.write("timestamp_ms,fps,heap_used_mb,heap_allocated_mb,heap_max_mb,player_chunk_x,player_chunk_z");
                    writer.newLine();
                    headerWritten = true;
                }
                writer.write(timestamp + "," + fps + "," + usedMb + "," + allocatedMb + "," + maxMb
                        + "," + chunkX + "," + chunkZ);
                writer.newLine();
            }
        } catch (IOException ignored) {
            // Diagnostics must never interrupt gameplay if storage is unavailable.
        }
    }
}
